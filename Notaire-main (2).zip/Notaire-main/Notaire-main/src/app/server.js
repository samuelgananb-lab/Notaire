const app = require('./app');
const env = require('./config/env');

function startServer() {
    const server = app.listen(
        env.PORT,
        () => {
            console.log('');
            console.log(
                '========================================'
            );
            console.log(
                '       NOTAIRE BACKEND'
            );
            console.log(
                '========================================'
            );
            console.log(
                `🚀 Servidor: http://localhost:${env.PORT}`
            );
            console.log(
                `❤️ Health:   http://localhost:${env.PORT}/api/health`
            );
            console.log(
                `🌐 Entorno:  ${env.NODE_ENV}`
            );
            console.log(
                '========================================'
            );
            console.log('');
        }
    );

    const shutdown = (signal) => {
        console.log(
            `\n🛑 Señal ${signal} recibida.`
        );

        server.close(() => {
            console.log(
                '✅ Servidor cerrado correctamente.'
            );

            process.exit(0);
        });
    };

    process.on(
        'SIGINT',
        () => shutdown('SIGINT')
    );

    process.on(
        'SIGTERM',
        () => shutdown('SIGTERM')
    );

    return server;
};

if (require.main === module) {
    startServer();
}

module.exports = {
    startServer
};
