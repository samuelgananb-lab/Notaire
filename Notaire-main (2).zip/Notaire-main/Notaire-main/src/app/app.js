const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const pinoHttp = require('pino-http');
const path = require('path');

const env = require('./config/env');
const authRoutes = require('../auth/auth.routes');
const notarioRoutes = require('../notarios/notario.routes');
const tramiteRoutes = require('../tramites/tramite.routes');

const {
    errorMiddleware,
    notFoundMiddleware
} = require('../lib/errors');

const app = express();

app.disable('x-powered-by');

app.use(
    helmet({
        crossOriginResourcePolicy: {
            policy: 'cross-origin'
        }
    })
);

app.use(
    cors({
        origin: env.CORS_ORIGIN,
        credentials: true
    })
);

app.use(
    express.json({
        limit: '2mb'
    })
);

app.use(
    express.urlencoded({
        extended: true,
        limit: '2mb'
    })
);

app.use(
    pinoHttp({
        level:
            env.NODE_ENV === 'development'
                ? 'info'
                : 'warn',
        redact: [
            'req.headers.authorization',
            'req.headers.cookie',
            'req.body.password',
            'req.body.refresh_token'
        ]
    })
);

const apiLimiter = rateLimit({
    windowMs: env.RATE_LIMIT_WINDOW_MS,
    limit: env.RATE_LIMIT_MAX,
    standardHeaders: 'draft-8',
    legacyHeaders: false,
    message: {
        success: false,
        error: {
            code: 'RATE_LIMITED',
            message: 'Demasiadas solicitudes. Intenta nuevamente más tarde.'
        }
    }
});

const authLimiter = rateLimit({
    windowMs: env.AUTH_RATE_LIMIT_WINDOW_MS,
    limit: env.AUTH_RATE_LIMIT_MAX,
    standardHeaders: 'draft-8',
    legacyHeaders: false,
    message: {
        success: false,
        error: {
            code: 'AUTH_RATE_LIMITED',
            message: 'Demasiados intentos de autenticación. Intenta más tarde.'
        }
    }
});

app.use('/api', apiLimiter);
app.use('/api/v1/auth', authLimiter, authRoutes);
app.use('/api/auth', authLimiter, authRoutes);
app.use('/api/notarios', apiLimiter, notarioRoutes);
app.use('/api/tramites', apiLimiter, tramiteRoutes);

app.get('/api/health', (req, res) => {
    res.json({
        success: true,
        service: 'notaire-api',
        status: 'ok',
        environment: env.NODE_ENV,
        timestamp: new Date().toISOString()
    });
});

app.get('/api/v1/health', (req, res) => {
    res.json({
        success: true,
        service: 'notaire-api',
        version: 'v1',
        status: 'ok',
        timestamp: new Date().toISOString()
    });
});

app.use(express.static(path.join(__dirname, '../../public')));

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../../public/index.html'));
});

app.use(notFoundMiddleware);
app.use(errorMiddleware);

module.exports = app;