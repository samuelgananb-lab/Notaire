const { createClient } = require('@supabase/supabase-js');
const env = require('./env');

let client = null;

function getSupabasePublic() {
    if (!env.SUPABASE_URL || !env.SUPABASE_ANON_KEY) {
        throw new Error('Supabase público no está configurado.');
    }

    if (!client) {
        client = createClient(env.SUPABASE_URL, env.SUPABASE_ANON_KEY, {
            auth: {
                autoRefreshToken: false,
                persistSession: false,
                detectSessionInUrl: false
            }
        });
    }

    return client;
}

module.exports = {
    getSupabasePublic
};
