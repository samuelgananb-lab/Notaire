const {
    createClient
} = require('@supabase/supabase-js');

const env = require('./env');

let client = null;

function getSupabaseAdmin() {
    if (!env.SUPABASE_URL || !env.SUPABASE_SERVICE_ROLE_KEY) {
        return null;
    }

    if (!client) {
        client = createClient(
            env.SUPABASE_URL,
            env.SUPABASE_SERVICE_ROLE_KEY,
            {
                auth: {
                    autoRefreshToken: false,
                    persistSession: false,
                    detectSessionInUrl: false
                }
            }
        );
    }

    return client;
}

const supabaseAdmin = getSupabaseAdmin();

module.exports = {
    getSupabaseAdmin,
    supabaseAdmin
};
