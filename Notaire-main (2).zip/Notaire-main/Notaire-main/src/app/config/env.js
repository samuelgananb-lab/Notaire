const dotenv = require('dotenv');

dotenv.config();

function getEnv(name, fallback = undefined) {
    const value = process.env[name];

    if (
        value === undefined ||
        value === ''
    ) {
        if (fallback !== undefined) {
            return fallback;
        }

        throw new Error(
            `Falta la variable de entorno: ${name}`
        );
    }

    return value;
}

function getNumberEnv(name, fallback) {
    const value = getEnv(name, String(fallback));
    const number = Number(value);

    if (!Number.isFinite(number)) {
        throw new Error(
            `La variable ${name} debe ser numérica`
        );
    }

    return number;
}

const env = {
    PORT: getNumberEnv('PORT', 3000),

    NODE_ENV: getEnv(
        'NODE_ENV',
        'development'
    ),

    SUPABASE_URL: getEnv(
        'SUPABASE_URL',
        ''
    ),

    SUPABASE_ANON_KEY: getEnv(
        'SUPABASE_ANON_KEY',
        ''
    ),

    SUPABASE_SERVICE_ROLE_KEY: getEnv(
        'SUPABASE_SERVICE_ROLE_KEY',
        ''
    ),

    CLAUDE_API_KEY: getEnv(
        'CLAUDE_API_KEY',
        ''
    ),

    CORS_ORIGIN: getEnv(
        'CORS_ORIGIN',
        'http://localhost:3000'
    ),

    RATE_LIMIT_WINDOW_MS:
        getNumberEnv(
            'RATE_LIMIT_WINDOW_MS',
            60000
        ),

    RATE_LIMIT_MAX:
        getNumberEnv(
            'RATE_LIMIT_MAX',
            100
        ),

    AUTH_RATE_LIMIT_WINDOW_MS:
        getNumberEnv(
            'AUTH_RATE_LIMIT_WINDOW_MS',
            900000
        ),

    AUTH_RATE_LIMIT_MAX:
        getNumberEnv(
            'AUTH_RATE_LIMIT_MAX',
            10
        )
};

module.exports = env;
