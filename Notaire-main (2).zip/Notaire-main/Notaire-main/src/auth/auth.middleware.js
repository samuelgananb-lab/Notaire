const { getSupabasePublic } = require('../app/config/supabasePublic');
const { getSupabaseAdmin } = require('../app/config/supabaseAdmin');
const {
    unauthorized,
    forbidden,
    AppError,
    supabaseNotConfigured
} = require('../lib/errors');

async function authMiddleware(req, res, next) {
    try {
        const authHeader = req.headers.authorization || '';
        const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7).trim() : '';

        if (!token) {
            throw unauthorized('Token de autenticación requerido.');
        }

        let supabase;
        try {
            supabase = getSupabasePublic();
        } catch (error) {
            throw supabaseNotConfigured();
        }

        const { data: userData, error } = await supabase.auth.getUser(token);

        if (error || !userData?.user) {
            throw unauthorized('Token inválido o expirado.');
        }

        const adminClient = getSupabaseAdmin();

        if (!adminClient) {
            throw supabaseNotConfigured();
        }

        const { data: profile, error: profileError } = await adminClient
            .from('usuarios')
            .select(`
                id,
                nombre,
                telefono,
                estado,
                rol_id,
                roles:rol_id (
                    id,
                    nombre
                )
            `)
            .eq('id', userData.user.id)
            .maybeSingle();

        if (profileError || !profile) {
            throw new AppError('Perfil no encontrado.', 404, 'PROFILE_NOT_FOUND');
        }

        if (profile.estado === 'suspended') {
            throw forbidden('Cuenta suspendida.');
        }

        if (profile.roles?.nombre === 'notario') {
            const { data: notarioProfile, error: notarioProfileError } = await adminClient
                .from('perfiles_notario')
                .select('estado')
                .eq('usuario_id', userData.user.id)
                .maybeSingle();

            if (notarioProfileError) {
                throw new AppError(
                    'No se pudo validar el perfil notarial.',
                    500,
                    'PROFILE_VALIDATION_ERROR'
                );
            }

            if (!notarioProfile || notarioProfile.estado !== 'active') {
                throw forbidden('El perfil notarial no está activo.');
            }
        }

        req.auth = {
            user: userData.user,
            profile: {
                id: profile.id,
                nombre: profile.nombre,
                telefono: profile.telefono || '',
                estado: profile.estado,
                rol: profile.roles?.nombre || 'cliente'
            },
            role: profile.roles?.nombre || 'cliente',
            token
        };

        return next();
    } catch (error) {
        return next(error);
    }
}

module.exports = {
    authMiddleware
};
