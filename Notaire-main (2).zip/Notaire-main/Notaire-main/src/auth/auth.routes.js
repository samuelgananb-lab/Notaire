const express = require('express');
const { authMiddleware } = require('./auth.middleware');
const { requireRoles } = require('./role.middleware');
const authController = require('./auth.controller');

const router = express.Router();

router.post('/register', authController.register);
router.post('/login', authController.login);
router.post('/logout', authController.logout);
router.post('/refresh', authController.refresh);
router.get('/me', authMiddleware, authController.me);
router.get('/verify', authMiddleware, authController.verify);

router.get('/admin-check', authMiddleware, requireRoles('admin'), (req, res) => {
    res.status(200).json({
        success: true,
        data: {
            role: req.auth.role,
            message: 'Acceso autorizado para administrador.'
        }
    });
});

module.exports = router;
