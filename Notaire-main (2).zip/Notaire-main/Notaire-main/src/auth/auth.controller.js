const { registerSchema, loginSchema } = require('./auth.schemas');
const authService = require('./auth.service');
const { badRequest, unauthorized, AppError } = require('../lib/errors');

async function register(req, res, next) {
    try {
        const parsed = registerSchema.safeParse(req.body);

        if (!parsed.success) {
            throw badRequest(parsed.error.issues[0]?.message || 'Datos de registro inválidos.');
        }

        const result = await authService.register(parsed.data);

        return res.status(201).json({
            success: true,
            data: result
        });
    } catch (error) {
        return next(error);
    }
}

async function login(req, res, next) {
    try {
        const parsed = loginSchema.safeParse(req.body);

        if (!parsed.success) {
            throw badRequest(parsed.error.issues[0]?.message || 'Datos de login inválidos.');
        }

        const result = await authService.login(parsed.data);

        return res.status(200).json({
            success: true,
            data: result
        });
    } catch (error) {
        return next(error);
    }
}

async function logout(req, res, next) {
    try {
        const token = req.headers.authorization?.startsWith('Bearer ')
            ? req.headers.authorization.slice(7).trim()
            : '';

        await authService.logout(token);

        return res.status(204).send();
    } catch (error) {
        return next(error);
    }
}

async function refresh(req, res, next) {
    try {
        const refreshToken = req.body?.refresh_token;

        if (!refreshToken) {
            throw unauthorized('Refresh token requerido.');
        }

        const result = await authService.refreshSession(refreshToken);

        return res.status(200).json({
            success: true,
            data: result
        });
    } catch (error) {
        return next(error);
    }
}

async function me(req, res, next) {
    try {
        if (!req.auth?.user?.id) {
            throw unauthorized('Usuario no autenticado.');
        }

        const profile = await authService.getProfile(req.auth.user.id);

        return res.status(200).json({
            success: true,
            data: {
                user: {
                    id: req.auth.user.id,
                    email: req.auth.user.email,
                    nombre: profile.nombre,
                    telefono: profile.telefono,
                    rol: profile.rol,
                    estado: profile.estado
                }
            }
        });
    } catch (error) {
        return next(error);
    }
}

async function verify(req, res, next) {
    try {
        if (!req.auth) {
            throw unauthorized('Token inválido o no autenticado.');
        }

        return res.status(200).json({
            success: true,
            authenticated: true,
            user: {
                id: req.auth.user.id,
                email: req.auth.user.email,
                nombre: req.auth.profile.nombre,
                rol: req.auth.role,
                estado: req.auth.profile.estado
            }
        });
    } catch (error) {
        return next(error);
    }
}

module.exports = {
    register,
    login,
    logout,
    refresh,
    me,
    verify
};
