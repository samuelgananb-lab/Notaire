const { getSupabasePublic } = require('../app/config/supabasePublic');
const { getSupabaseAdmin } = require('../app/config/supabaseAdmin');
const {
    unauthorized,
    forbidden,
    AppError,
    supabaseNotConfigured
} = require('../lib/errors');

function ensurePublicSupabase() {
    try {
        return getSupabasePublic();
    } catch (error) {
        throw supabaseNotConfigured();
    }
}

function ensureAdminSupabase() {
    const adminClient = getSupabaseAdmin();

    if (!adminClient) {
        throw supabaseNotConfigured();
    }

    return adminClient;
}

async function register(data) {
    const supabase = ensurePublicSupabase();
    const { nombre, telefono, email, password } = data;

    const { data: signUpData, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
            data: {
                nombre,
                telefono: telefono || ''
            }
        }
    });

    if (error) {
        throw new AppError(
            error.message || 'No se pudo registrar el usuario.',
            400,
            'REGISTRATION_FAILED'
        );
    }

    if (!signUpData.user) {
        throw new AppError('No se pudo crear el usuario.', 400, 'REGISTRATION_FAILED');
    }

    return {
        user: {
            id: signUpData.user.id,
            email: signUpData.user.email,
            nombre,
            telefono: telefono || ''
        },
        session: signUpData.session || null
    };
}

async function login(data) {
    const supabase = ensurePublicSupabase();
    const { email, password } = data;

    const { data: signInData, error } = await supabase.auth.signInWithPassword({
        email,
        password
    });

    if (error) {
        throw new AppError('Credenciales inválidas.', 401, 'INVALID_CREDENTIALS');
    }

    if (!signInData.user) {
        throw new AppError('No se pudo iniciar sesión.', 401, 'AUTH_SERVICE_ERROR');
    }

    const adminClient = ensureAdminSupabase();
    const { data: profileData, error: profileError } = await adminClient
        .from('usuarios')
        .select(`
            id,
            nombre,
            telefono,
            estado,
            rol_id,
            roles:rol_id (
                id,
                nombre
            )
        `)
        .eq('id', signInData.user.id)
        .maybeSingle();

    if (profileError || !profileData) {
        throw new AppError('Perfil no encontrado.', 404, 'PROFILE_NOT_FOUND');
    }

    const roleName = profileData.roles?.nombre || 'cliente';

    if (profileData.estado === 'suspended') {
        throw new AppError('Cuenta suspendida.', 403, 'ACCOUNT_SUSPENDED');
    }

    return {
        user: {
            id: profileData.id,
            email: signInData.user.email,
            nombre: profileData.nombre,
            telefono: profileData.telefono || '',
            rol: roleName,
            estado: profileData.estado
        },
        session: signInData.session
    };
}

async function logout(token) {
    if (!token) {
        return { success: true };
    }

    const adminClient = ensureAdminSupabase();
    const { error } = await adminClient.auth.admin.signOut(token, 'local');

    if (error) {
        throw new AppError('No se pudo cerrar la sesión.', 400, 'LOGOUT_FAILED');
    }

    return { success: true };
}

async function refreshSession(refreshToken) {
    const supabase = ensurePublicSupabase();

    if (!refreshToken) {
        throw unauthorized('Refresh token requerido.');
    }

    const { data, error } = await supabase.auth.refreshSession({ refresh_token: refreshToken });

    if (error || !data.session) {
        throw unauthorized('Sesión inválida o expirada.');
    }

    return data;
}

async function getProfile(userId) {
    if (!userId) {
        throw unauthorized('Usuario no autenticado.');
    }

    const adminClient = ensureAdminSupabase();
    const { data, error } = await adminClient
        .from('usuarios')
        .select(`
            id,
            nombre,
            telefono,
            estado,
            rol_id,
            roles:rol_id (
                id,
                nombre
            )
        `)
        .eq('id', userId)
        .maybeSingle();

    if (error || !data) {
        throw new AppError('Perfil no encontrado.', 404, 'PROFILE_NOT_FOUND');
    }

    if (data.estado === 'suspended') {
        throw forbidden('Cuenta suspendida.');
    }

    return {
        id: data.id,
        nombre: data.nombre,
        telefono: data.telefono || '',
        estado: data.estado,
        rol: data.roles?.nombre || 'cliente'
    };
}

module.exports = {
    register,
    login,
    logout,
    refreshSession,
    getProfile
};
