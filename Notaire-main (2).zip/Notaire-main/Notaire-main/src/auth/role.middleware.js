const { unauthorized, forbidden } = require('../lib/errors');

function requireRoles(...allowedRoles) {
    return (req, res, next) => {
        if (!req.auth) {
            return next(unauthorized('Se requiere autenticación.'));
        }

        const role = req.auth.role;

        if (!allowedRoles.includes(role)) {
            return next(forbidden('No tienes permisos para realizar esta acción.'));
        }

        return next();
    };
}

module.exports = {
    requireRoles
};
