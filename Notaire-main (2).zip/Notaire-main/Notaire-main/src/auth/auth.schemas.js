const { z } = require('zod');

const registerSchema = z.object({
    nombre: z
        .string()
        .trim()
        .min(2, 'El nombre debe tener al menos 2 caracteres')
        .max(100, 'El nombre es demasiado largo'),

    telefono: z
        .string()
        .trim()
        .max(20, 'El teléfono es demasiado largo')
        .optional()
        .default(''),

    email: z
        .string()
        .trim()
        .email('El correo no es válido')
        .max(255, 'El correo es demasiado largo')
        .transform(value => value.toLowerCase()),

    password: z
        .string()
        .min(8, 'La contraseña debe tener al menos 8 caracteres')
        .max(128, 'La contraseña es demasiado larga')
}).strict();

const loginSchema = z.object({
    email: z
        .string()
        .trim()
        .email('El correo no es válido')
        .max(255, 'El correo es demasiado largo')
        .transform(value => value.toLowerCase()),

    password: z
        .string()
        .min(1, 'La contraseña es obligatoria')
        .max(128, 'La contraseña es demasiado larga')
}).strict();

module.exports = {
    registerSchema,
    loginSchema
};
