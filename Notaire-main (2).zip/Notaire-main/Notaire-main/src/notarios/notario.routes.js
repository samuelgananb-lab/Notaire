const express = require('express');
const { authMiddleware } = require('../auth/auth.middleware');
const { requireRoles } = require('../auth/role.middleware');
const controller = require('./notario.controller');

const router = express.Router();

router.use(authMiddleware);
router.get('/perfil', requireRoles('notario'), controller.own);
router.patch('/perfil', requireRoles('notario'), controller.updateOwn);
router.get('/', requireRoles('admin'), controller.list);
router.get('/:usuarioId', requireRoles('admin'), controller.get);
router.post('/', requireRoles('admin'), controller.create);
router.patch('/:usuarioId', requireRoles('admin'), controller.update);

module.exports = router;