const notarioService = require('./notario.service');
const {
    notarioProfileUpdateSchema,
    adminNotarioProfileSchema,
    adminNotarioProfileUpdateSchema,
    usuarioIdSchema
} = require('./notario.schemas');
const { badRequest } = require('../lib/errors');

function parse(schema, body) {
    const parsed = schema.safeParse(body);
    if (!parsed.success) throw badRequest(parsed.error.issues[0]?.message || 'Payload inválido.');
    return parsed.data;
}

function parseUsuarioId(value) {
    const parsed = usuarioIdSchema.safeParse(value);
    if (!parsed.success) throw badRequest('Identificador de usuario inválido.');
    return parsed.data;
}

async function own(req, res, next) {
    try {
        const data = await notarioService.getOwnProfile(req.auth.user.id);
        return res.status(200).json({ success: true, data });
    } catch (error) { return next(error); }
}

async function updateOwn(req, res, next) {
    try {
        const data = parse(notarioProfileUpdateSchema, req.body);
        const result = await notarioService.updateProfile(req.auth.user.id, data);
        return res.status(200).json({ success: true, data: result });
    } catch (error) { return next(error); }
}

async function list(req, res, next) {
    try {
        const data = await notarioService.listProfiles();
        return res.status(200).json({ success: true, data });
    } catch (error) { return next(error); }
}

async function get(req, res, next) {
    try {
        const data = await notarioService.getProfile(parseUsuarioId(req.params.usuarioId));
        return res.status(200).json({ success: true, data });
    } catch (error) { return next(error); }
}

async function create(req, res, next) {
    try {
        const data = parse(adminNotarioProfileSchema, req.body);
        const result = await notarioService.createProfile(data);
        return res.status(201).json({ success: true, data: result });
    } catch (error) { return next(error); }
}

async function update(req, res, next) {
    try {
        const data = parse(adminNotarioProfileUpdateSchema, req.body);
        const result = await notarioService.updateProfile(parseUsuarioId(req.params.usuarioId), data, true);
        return res.status(200).json({ success: true, data: result });
    } catch (error) { return next(error); }
}

module.exports = { own, updateOwn, list, get, create, update };