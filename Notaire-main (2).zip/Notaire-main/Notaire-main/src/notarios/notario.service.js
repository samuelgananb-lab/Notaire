const { getSupabaseAdmin } = require('../app/config/supabaseAdmin');
const { AppError, conflict, forbidden, notFound, supabaseNotConfigured } = require('../lib/errors');

const profileSelect = `
    usuario_id,
    numero_licencia,
    especialidad,
    experiencia_anios,
    biografia,
    estado,
    creado_en,
    actualizado_en
`;

function adminClient() {
    const client = getSupabaseAdmin();
    if (!client) {
        throw supabaseNotConfigured('El servicio de datos no está configurado.');
    }
    return client;
}

function throwDatabaseError(error, fallback = 'No se pudo completar la operación.') {
    if (error?.code === '23505') {
        throw conflict('Ya existe un perfil con ese número de licencia.');
    }
    throw new AppError(fallback, 500, 'DATABASE_ERROR');
}

async function ensureNotarioUser(usuarioId) {
    const { data, error } = await adminClient()
        .from('usuarios')
        .select('id, roles:rol_id(nombre), estado')
        .eq('id', usuarioId)
        .maybeSingle();

    if (error) throwDatabaseError(error, 'No se pudo validar el usuario.');
    if (!data) throw notFound('Usuario no encontrado.');
    if (data.roles?.nombre !== 'notario') {
        throw forbidden('El usuario debe tener rol notario.');
    }
    if (data.estado === 'suspended') {
        throw forbidden('El usuario está suspendido.');
    }
}

async function getOwnProfile(usuarioId) {
    const { data, error } = await adminClient()
        .from('perfiles_notario')
        .select(profileSelect)
        .eq('usuario_id', usuarioId)
        .maybeSingle();

    if (error) throwDatabaseError(error);
    if (!data) throw notFound('Perfil de notario no encontrado.');
    return data;
}

async function listProfiles() {
    const { data, error } = await adminClient()
        .from('perfiles_notario')
        .select(profileSelect)
        .order('creado_en', { ascending: false });

    if (error) throwDatabaseError(error);
    return data || [];
}

async function getProfile(usuarioId) {
    return getOwnProfile(usuarioId);
}

async function createProfile(data) {
    await ensureNotarioUser(data.usuario_id);
    const { usuario_id: ignored, ...profile } = data;
    const { data: created, error } = await adminClient()
        .from('perfiles_notario')
        .insert({ usuario_id: data.usuario_id, ...profile })
        .select(profileSelect)
        .single();

    if (error) throwDatabaseError(error);
    return created;
}

async function updateProfile(usuarioId, data, isAdmin = false) {
    if (isAdmin && data.estado === 'active') {
        await ensureNotarioUser(usuarioId);
    }

    const { data: updated, error } = await adminClient()
        .from('perfiles_notario')
        .update(data)
        .eq('usuario_id', usuarioId)
        .select(profileSelect)
        .maybeSingle();

    if (error) throwDatabaseError(error);
    if (!updated) throw notFound('Perfil de notario no encontrado.');
    return updated;
}

module.exports = {
    getOwnProfile,
    listProfiles,
    getProfile,
    createProfile,
    updateProfile
};