const { z } = require('zod');

const usuarioIdSchema = z.string().uuid();

const profileFields = {
    numero_licencia: z.string().trim().min(1).max(80),
    especialidad: z.string().trim().max(120).nullable().optional(),
    experiencia_anios: z.number().int().min(0).max(80).optional(),
    biografia: z.string().trim().max(5000).nullable().optional(),
    estado: z.enum(['active', 'inactive', 'suspended']).optional()
};

const notarioProfileSchema = z.object({
    ...profileFields
}).strict();

const notarioProfileUpdateSchema = z.object({
    especialidad: profileFields.especialidad,
    experiencia_anios: profileFields.experiencia_anios,
    biografia: profileFields.biografia
}).strict().refine((value) => Object.keys(value).length > 0, {
    message: 'Debes enviar al menos un campo actualizable.'
});

const adminNotarioProfileSchema = notarioProfileSchema.extend({
    usuario_id: usuarioIdSchema
});

const adminNotarioProfileUpdateSchema = adminNotarioProfileSchema.partial().omit({
    usuario_id: true
}).strict().refine((value) => Object.keys(value).length > 0, {
    message: 'Debes enviar al menos un campo actualizable.'
});

module.exports = {
    notarioProfileSchema,
    usuarioIdSchema,
    notarioProfileUpdateSchema,
    adminNotarioProfileSchema,
    adminNotarioProfileUpdateSchema
};