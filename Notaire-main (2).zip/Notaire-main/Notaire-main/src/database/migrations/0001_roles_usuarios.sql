create table if not exists public.roles (
    id serial primary key,
    nombre varchar(20) not null unique,
    constraint roles_nombre_check
        check (nombre in ('admin', 'notario', 'cliente'))
);

insert into public.roles (id, nombre)
values
    (1, 'admin'),
    (2, 'notario'),
    (3, 'cliente')
on conflict (id) do update
set nombre = excluded.nombre;

create table if not exists public.usuarios (
    id uuid primary key
        references auth.users(id)
        on delete cascade,

    nombre varchar(100),
    telefono varchar(20),
    rol_id integer not null
        references public.roles(id),
    estado varchar(12) not null default 'active',
    creado_en timestamptz not null default now(),
    actualizado_en timestamptz not null default now(),

    constraint usuarios_estado_check
        check (estado in ('active', 'suspended'))
);

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
    insert into public.usuarios (
        id,
        nombre,
        telefono,
        rol_id,
        estado
    )
    values (
        new.id,
        coalesce(
            new.raw_user_meta_data ->> 'nombre',
            new.raw_user_meta_data ->> 'name',
            ''
        ),
        coalesce(
            new.raw_user_meta_data ->> 'telefono',
            new.raw_user_meta_data ->> 'phone',
            ''
        ),
        3,
        'active'
    )
    on conflict (id) do nothing;

    return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;

create trigger on_auth_user_created
after insert on auth.users
for each row
execute function public.handle_new_user();

create index if not exists idx_usuarios_rol_id
on public.usuarios(rol_id);

create index if not exists idx_usuarios_estado
on public.usuarios(estado);

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
    new.actualizado_en = now();
    return new;
end;
$$;

drop trigger if exists usuarios_set_updated_at on public.usuarios;

create trigger usuarios_set_updated_at
before update on public.usuarios
for each row
execute function public.set_updated_at();
