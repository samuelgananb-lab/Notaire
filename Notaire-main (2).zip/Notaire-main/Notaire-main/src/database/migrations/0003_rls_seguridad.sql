-- Fase 3 security hardening: RLS for the tables currently used by the API.
-- Apply from Supabase SQL Editor after reviewing the policies in this file.
-- The Express backend uses service_role, which bypasses RLS by design.

create or replace function public.rol_actual()
returns text
language sql
stable
security definer
set search_path = pg_catalog, public
as $$
    select r.nombre
    from public.usuarios as u
    join public.roles as r on r.id = u.rol_id
    where u.id = auth.uid()
      and u.estado = 'active'
    limit 1;
$$;

revoke all on function public.rol_actual() from public;
grant execute on function public.rol_actual() to anon, authenticated;

alter table public.usuarios enable row level security;
alter table public.perfiles_notario enable row level security;
alter table public.tipos_tramite enable row level security;
alter table public.tramites enable row level security;

-- Keep direct access narrow. service_role is intentionally not changed here.
revoke all on table public.usuarios from anon, authenticated;
revoke all on table public.perfiles_notario from anon, authenticated;
revoke all on table public.tipos_tramite from anon, authenticated;
revoke all on table public.tramites from anon, authenticated;

grant select on table public.usuarios to authenticated;
grant select on table public.perfiles_notario to authenticated;
grant select on table public.tipos_tramite to authenticated;
grant select on table public.tramites to authenticated;
grant insert on table public.tramites to authenticated;
grant insert, update, delete on table public.tipos_tramite to authenticated;
grant insert, update, delete on table public.tramites to authenticated;
grant usage, select on sequence public.tipos_tramite_id_seq to authenticated;

-- Remove only policies owned by this migration so it can be reapplied safely.
do $$
begin
    execute 'drop policy if exists usuarios_select_own on public.usuarios';
    execute 'drop policy if exists usuarios_select_admin on public.usuarios';
    execute 'drop policy if exists perfiles_notario_select_own on public.perfiles_notario';
    execute 'drop policy if exists perfiles_notario_select_admin on public.perfiles_notario';
    execute 'drop policy if exists tipos_tramite_select_authenticated on public.tipos_tramite';
    execute 'drop policy if exists tipos_tramite_admin_insert on public.tipos_tramite';
    execute 'drop policy if exists tipos_tramite_admin_update on public.tipos_tramite';
    execute 'drop policy if exists tipos_tramite_admin_delete on public.tipos_tramite';
    execute 'drop policy if exists tramites_select_client on public.tramites';
    execute 'drop policy if exists tramites_select_notary on public.tramites';
    execute 'drop policy if exists tramites_select_admin on public.tramites';
    execute 'drop policy if exists tramites_insert_client on public.tramites';
    execute 'drop policy if exists tramites_update_notary on public.tramites';
    execute 'drop policy if exists tramites_admin_insert on public.tramites';
    execute 'drop policy if exists tramites_admin_update on public.tramites';
    execute 'drop policy if exists tramites_admin_delete on public.tramites';
end;
$$;

-- Profiles: read-only self/admin access. All writes remain in the backend.
create policy usuarios_select_own
on public.usuarios
for select
to authenticated
using (id = auth.uid());

create policy usuarios_select_admin
on public.usuarios
for select
to authenticated
using (public.rol_actual() = 'admin');

create policy perfiles_notario_select_own
on public.perfiles_notario
for select
to authenticated
using (usuario_id = auth.uid() and public.rol_actual() = 'notario');

create policy perfiles_notario_select_admin
on public.perfiles_notario
for select
to authenticated
using (public.rol_actual() = 'admin');

-- Types: authenticated users may read; only admins may write.
create policy tipos_tramite_select_authenticated
on public.tipos_tramite
for select
to authenticated
using (public.rol_actual() in ('cliente', 'notario', 'admin'));

create policy tipos_tramite_admin_insert
on public.tipos_tramite
for insert
to authenticated
with check (public.rol_actual() = 'admin');

create policy tipos_tramite_admin_update
on public.tipos_tramite
for update
to authenticated
using (public.rol_actual() = 'admin')
with check (public.rol_actual() = 'admin');

create policy tipos_tramite_admin_delete
on public.tipos_tramite
for delete
to authenticated
using (public.rol_actual() = 'admin');

-- Procedures: clients can create only an unassigned request for themselves.
create policy tramites_select_client
on public.tramites
for select
to authenticated
using (cliente_id = auth.uid() and public.rol_actual() = 'cliente');

create policy tramites_select_notary
on public.tramites
for select
to authenticated
using (notario_id = auth.uid() and public.rol_actual() = 'notario');

create policy tramites_select_admin
on public.tramites
for select
to authenticated
using (public.rol_actual() = 'admin');

create policy tramites_insert_client
on public.tramites
for insert
to authenticated
with check (
    cliente_id = auth.uid()
    and notario_id is null
    and estado = 'solicitado'
    and public.rol_actual() = 'cliente'
);

create policy tramites_update_notary
on public.tramites
for update
to authenticated
using (notario_id = auth.uid() and public.rol_actual() = 'notario')
with check (notario_id = auth.uid() and public.rol_actual() = 'notario');

create policy tramites_admin_insert
on public.tramites
for insert
to authenticated
with check (public.rol_actual() = 'admin');

create policy tramites_admin_update
on public.tramites
for update
to authenticated
using (public.rol_actual() = 'admin')
with check (public.rol_actual() = 'admin');

create policy tramites_admin_delete
on public.tramites
for delete
to authenticated
using (public.rol_actual() = 'admin');

-- PostgreSQL column grants are shared by all authenticated users. This trigger
-- supplies the missing column-level distinction for direct notary updates.
create or replace function public.proteger_tramite_update()
returns trigger
language plpgsql
security definer
set search_path = pg_catalog, public
as $$
declare
    jwt_role text;
    app_role text;
begin
    jwt_role := coalesce(
        nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role',
        ''
    );

    if jwt_role = 'service_role' then
        return new;
    end if;

    app_role := public.rol_actual();

    if app_role = 'admin' then
        return new;
    end if;

    if app_role = 'notario'
       and old.notario_id = auth.uid()
       and new.cliente_id = old.cliente_id
       and new.notario_id = old.notario_id
       and new.tipo_tramite_id = old.tipo_tramite_id
       and new.titulo = old.titulo
       and new.estado in ('en_proceso', 'completado', 'cancelado') then
        return new;
    end if;

    raise exception 'Los campos administrativos del trámite no pueden modificarse directamente';
end;
$$;

revoke all on function public.proteger_tramite_update() from public;
grant execute on function public.proteger_tramite_update() to authenticated;

drop trigger if exists proteger_tramite_update on public.tramites;
create trigger proteger_tramite_update
before update on public.tramites
for each row
execute function public.proteger_tramite_update();

-- No INSERT/UPDATE/DELETE policies are created for usuarios or perfiles_notario.
-- No anonymous policies are created. service_role bypasses RLS for the API backend.
