const express = require('express');
const { authMiddleware } = require('../auth/auth.middleware');
const { requireRoles } = require('../auth/role.middleware');
const controller = require('./tramite.controller');

const router = express.Router();

router.use(authMiddleware);
router.get('/tipos', controller.listTypes);
router.get('/tipos/:id', controller.getType);
router.post('/tipos', requireRoles('admin'), controller.createType);
router.put('/tipos/:id', requireRoles('admin'), controller.updateType);
router.delete('/tipos/:id', requireRoles('admin'), controller.deleteType);

router.post('/', controller.create);
router.get('/', controller.list);
router.get('/:id', controller.get);
router.patch('/:id', controller.update);
router.patch('/:id/asignar-notario', requireRoles('admin'), controller.assignNotario);

module.exports = router;