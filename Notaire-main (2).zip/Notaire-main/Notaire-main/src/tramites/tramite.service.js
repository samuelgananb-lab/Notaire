const { getSupabaseAdmin } = require('../app/config/supabaseAdmin');
const { AppError, conflict, forbidden, notFound, supabaseNotConfigured } = require('../lib/errors');

const tramiteSelect = `
    id,
    cliente_id,
    notario_id,
    tipo_tramite_id,
    titulo,
    descripcion,
    estado,
    creado_en,
    actualizado_en,
    tipos_tramite:tipo_tramite_id (
        id,
        nombre,
        descripcion,
        activo
    )
`;

function adminClient() {
    const client = getSupabaseAdmin();
    if (!client) {
        throw supabaseNotConfigured('El servicio de datos no está configurado.');
    }
    return client;
}

function throwDatabaseError(error, fallback = 'No se pudo completar la operación.') {
    if (error?.code === '23505') throw conflict('El recurso ya existe.');
    if (error?.code === '23503') throw notFound('Una relación indicada no existe.');
    throw new AppError(fallback, 500, 'DATABASE_ERROR');
}

async function getType(id, onlyActive = false) {
    let query = adminClient().from('tipos_tramite').select('*').eq('id', id);
    if (onlyActive) query = query.eq('activo', true);
    const { data, error } = await query.maybeSingle();
    if (error) throwDatabaseError(error);
    if (!data) throw notFound('Tipo de trámite no encontrado.');
    return data;
}

async function listTypes(onlyActive = true) {
    let query = adminClient().from('tipos_tramite').select('*').order('nombre');
    if (onlyActive) query = query.eq('activo', true);
    const { data, error } = await query;
    if (error) throwDatabaseError(error);
    return data || [];
}

async function createType(data) {
    const { data: created, error } = await adminClient()
        .from('tipos_tramite').insert(data).select('*').single();
    if (error) throwDatabaseError(error);
    return created;
}

async function updateType(id, data) {
    await getType(id, false);
    const { data: updated, error } = await adminClient()
        .from('tipos_tramite').update(data).eq('id', id).select('*').single();
    if (error) throwDatabaseError(error);
    return updated;
}

async function deactivateType(id) {
    return updateType(id, { activo: false });
}

async function createTramite(clienteId, data) {
    await getType(data.tipo_tramite_id, true);
    const { data: created, error } = await adminClient()
        .from('tramites')
        .insert({ ...data, cliente_id: clienteId })
        .select(tramiteSelect)
        .single();
    if (error) throwDatabaseError(error);
    return created;
}

function scopedQuery(role, userId) {
    const query = adminClient().from('tramites').select(tramiteSelect);
    if (role === 'cliente') return query.eq('cliente_id', userId);
    if (role === 'notario') return query.eq('notario_id', userId);
    return query;
}

async function listTramites(role, userId) {
    const { data, error } = await scopedQuery(role, userId).order('creado_en', { ascending: false });
    if (error) throwDatabaseError(error);
    return data || [];
}

async function getTramite(role, userId, id) {
    const { data, error } = await scopedQuery(role, userId).eq('id', id).maybeSingle();
    if (error) throwDatabaseError(error);
    if (!data) throw notFound('Trámite no encontrado o no accesible.');
    return data;
}

async function updateTramite(role, userId, id, changes) {
    await getTramite(role, userId, id);
    if (role === 'cliente' && changes.estado && changes.estado !== 'cancelado') {
        throw forbidden('El cliente solo puede cancelar un trámite propio.');
    }
    const query = adminClient().from('tramites').update(changes).eq('id', id);
    if (role === 'cliente') query.eq('cliente_id', userId);
    if (role === 'notario') query.eq('notario_id', userId);
    const { data, error } = await query.select(tramiteSelect).maybeSingle();
    if (error) throwDatabaseError(error);
    if (!data) throw notFound('Trámite no encontrado o no accesible.');
    return data;
}

async function ensureActiveNotario(notarioId) {
    const { data, error } = await adminClient()
        .from('perfiles_notario').select('usuario_id').eq('usuario_id', notarioId).eq('estado', 'active').maybeSingle();
    if (error) throwDatabaseError(error);
    if (!data) throw notFound('Perfil de notario activo no encontrado.');
}

async function assignNotario(id, notarioId) {
    await ensureActiveNotario(notarioId);
    const { data, error } = await adminClient()
        .from('tramites').update({ notario_id: notarioId, estado: 'asignado' })
        .eq('id', id).select(tramiteSelect).maybeSingle();
    if (error) throwDatabaseError(error);
    if (!data) throw notFound('Trámite no encontrado.');
    return data;
}

module.exports = {
    listTypes,
    getType,
    createType,
    updateType,
    deactivateType,
    createTramite,
    listTramites,
    getTramite,
    updateTramite,
    assignNotario
};