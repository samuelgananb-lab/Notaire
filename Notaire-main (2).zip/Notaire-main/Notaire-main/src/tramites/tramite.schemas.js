const { z } = require('zod');

const idSchema = z.string().uuid();
const tipoTramiteIdSchema = z.coerce.number().int().positive();

const tipoTramiteCreateSchema = z.object({
    nombre: z.string().trim().min(1).max(120),
    descripcion: z.string().trim().max(5000).nullable().optional(),
    activo: z.boolean().optional()
}).strict();

const tipoTramiteUpdateSchema = tipoTramiteCreateSchema.partial().strict().refine(
    (value) => Object.keys(value).length > 0,
    { message: 'Debes enviar al menos un campo actualizable.' }
);

const tramiteCreateSchema = z.object({
    tipo_tramite_id: z.coerce.number().int().positive(),
    titulo: z.string().trim().min(1).max(160),
    descripcion: z.string().trim().max(10000).nullable().optional()
}).strict();

const clienteTramiteUpdateSchema = z.object({
    titulo: z.string().trim().min(1).max(160).optional(),
    descripcion: z.string().trim().max(10000).nullable().optional(),
    estado: z.enum(['cancelado']).optional()
}).strict().refine((value) => Object.keys(value).length > 0, {
    message: 'Debes enviar al menos un campo actualizable.'
});

const notarioTramiteUpdateSchema = z.object({
    descripcion: z.string().trim().max(10000).nullable().optional(),
    estado: z.enum(['en_proceso', 'completado', 'cancelado']).optional()
}).strict().refine((value) => Object.keys(value).length > 0, {
    message: 'Debes enviar al menos un campo actualizable.'
});

const adminTramiteUpdateSchema = z.object({
    titulo: z.string().trim().min(1).max(160).optional(),
    descripcion: z.string().trim().max(10000).nullable().optional(),
    estado: z.enum(['solicitado', 'asignado', 'en_proceso', 'completado', 'cancelado']).optional(),
    tipo_tramite_id: z.coerce.number().int().positive().optional()
}).strict().refine((value) => Object.keys(value).length > 0, {
    message: 'Debes enviar al menos un campo actualizable.'
});

const assignNotarioSchema = z.object({
    notario_id: idSchema
}).strict();

module.exports = {
    idSchema,
    tipoTramiteIdSchema,
    tipoTramiteCreateSchema,
    tipoTramiteUpdateSchema,
    tramiteCreateSchema,
    clienteTramiteUpdateSchema,
    notarioTramiteUpdateSchema,
    adminTramiteUpdateSchema,
    assignNotarioSchema
};