const service = require('./tramite.service');
const schemas = require('./tramite.schemas');
const { badRequest, forbidden } = require('../lib/errors');

function parse(schema, body) {
    const parsed = schema.safeParse(body);
    if (!parsed.success) throw badRequest(parsed.error.issues[0]?.message || 'Payload inválido.');
    return parsed.data;
}

function parseId(value) {
    const parsed = schemas.idSchema.safeParse(value);
    if (!parsed.success) throw badRequest('Identificador inválido.');
    return parsed.data;
}

function parseTipoId(value) {
    const parsed = schemas.tipoTramiteIdSchema.safeParse(value);
    if (!parsed.success) throw badRequest('Identificador de tipo de trámite inválido.');
    return parsed.data;
}

async function listTypes(req, res, next) {
    try {
        const data = await service.listTypes(req.auth.role !== 'admin');
        return res.status(200).json({ success: true, data });
    } catch (error) { return next(error); }
}

async function getType(req, res, next) {
    try {
        const data = await service.getType(parseTipoId(req.params.id), req.auth.role !== 'admin');
        return res.status(200).json({ success: true, data });
    } catch (error) { return next(error); }
}

async function createType(req, res, next) {
    try {
        const data = await service.createType(parse(schemas.tipoTramiteCreateSchema, req.body));
        return res.status(201).json({ success: true, data });
    } catch (error) { return next(error); }
}

async function updateType(req, res, next) {
    try {
        const data = await service.updateType(parseTipoId(req.params.id), parse(schemas.tipoTramiteUpdateSchema, req.body));
        return res.status(200).json({ success: true, data });
    } catch (error) { return next(error); }
}

async function deleteType(req, res, next) {
    try {
        await service.deactivateType(parseTipoId(req.params.id));
        return res.status(204).send();
    } catch (error) { return next(error); }
}

async function create(req, res, next) {
    try {
        if (req.auth.role !== 'cliente') throw forbidden('Solo un cliente puede crear trámites.');
        const data = await service.createTramite(req.auth.user.id, parse(schemas.tramiteCreateSchema, req.body));
        return res.status(201).json({ success: true, data });
    } catch (error) { return next(error); }
}

async function list(req, res, next) {
    try {
        const data = await service.listTramites(req.auth.role, req.auth.user.id);
        return res.status(200).json({ success: true, data });
    } catch (error) { return next(error); }
}

async function get(req, res, next) {
    try {
        const data = await service.getTramite(req.auth.role, req.auth.user.id, parseId(req.params.id));
        return res.status(200).json({ success: true, data });
    } catch (error) { return next(error); }
}

async function update(req, res, next) {
    try {
        const schema = req.auth.role === 'cliente'
            ? schemas.clienteTramiteUpdateSchema
            : req.auth.role === 'notario'
                ? schemas.notarioTramiteUpdateSchema
                : schemas.adminTramiteUpdateSchema;
        const data = await service.updateTramite(req.auth.role, req.auth.user.id, parseId(req.params.id), parse(schema, req.body));
        return res.status(200).json({ success: true, data });
    } catch (error) { return next(error); }
}

async function assignNotario(req, res, next) {
    try {
        const data = parse(schemas.assignNotarioSchema, req.body);
        const result = await service.assignNotario(parseId(req.params.id), data.notario_id);
        return res.status(200).json({ success: true, data: result });
    } catch (error) { return next(error); }
}

module.exports = {
    listTypes, getType, createType, updateType, deleteType,
    create, list, get, update, assignNotario
};