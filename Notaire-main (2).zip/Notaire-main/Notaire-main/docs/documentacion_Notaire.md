# Documentación del Proyecto Notaire

## Resumen
Este documento describe la estructura y el propósito del proyecto "Notaire". Se enfoca en una arquitectura limpia y minimalista para facilitar el mantenimiento y la escalabilidad.

## Estructura de Directorios (Actualizada)

Tras la reorganización, el proyecto mantiene una separación clara entre el backend y el frontend:

### 1. Directorio `public/` (Frontend)
Es la carpeta raíz de los archivos estáticos servidos por Express.
- **`index.html`**: La landing page principal de Notaire.
- **`assets/`**: Contiene los recursos compartidos.
  - `css/`: Estilos como `landing.css`.
  - `js/`: Lógica cliente como `landing.js`.
  - `image/`: Imágenes y recursos visuales.
- **`auth/`**: Contiene `login.html`, `register.html` y sus activos relacionados.
- **`panel_control/`**: Dashboards específicos para cada rol de usuario (Admin, Cliente).

### 2. Directorio `src/` (Backend)
- **`src/app/server.js`**: Inicia el servidor Express y expone la API actual. La base activa es Supabase PostgreSQL y la autenticación utiliza Supabase Auth/JWT.

### 3. Directorio `docs/`
- Espacio centralizado para la documentación técnica, manuales de usuario y especificaciones de negocio (como este archivo).

## Usuarios de Prueba (Demo)

Para propósitos de demostración y pruebas de integración, se han preconfigurado los siguientes usuarios:

| Rol | Correo Electrónico | Credencial | Destino (Dashboard) |
| --- | --- | --- | --- |
| **Administrador** | Legacy | No documentada | `panel_control/admin/` |
| **Cliente** | Legacy | No documentada | `panel_control/cliente/` |

## Seguridad y Protección de Rutas

Para garantizar la integridad del sistema y la privacidad de los usuarios, se ha implementado un esquema de seguridad de doble capa:

### 1. Protección de la API
Las rutas API protegidas validan el Bearer JWT mediante Supabase Auth y consultan el perfil de `public.usuarios`.
- El middleware de roles restringe las operaciones administrativas de la API.

### 2. Protección de Frontend (`auth-guard.js`)
Cada dashboard incluye un script ligero llamado `auth-guard.js` que:
- Realiza una comprobación instantánea al cargar la página para evitar visualizaciones accidentales de contenido protegido (flash of protected content).
- Gestiona el estado de la sesión en el navegador.
- Centraliza la función `logout()` para garantizar que la sesión se cierre correctamente tanto en el cliente como en el servidor.

### 3. Gestión de API
- Los endpoints sensibles de la API requieren un Bearer JWT válido.
- Las Fases 1, 2 y 3 están implementadas y verificadas contra Supabase.
- La Fase 4 todavía no está implementada.

## Conclusión
La arquitectura actual utiliza Express, Supabase PostgreSQL y módulos separados para autenticación, notarios y trámites. La integración JWT del frontend legacy queda pendiente para una etapa específica; no forma parte de la Fase 4.
