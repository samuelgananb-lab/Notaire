const request = require('supertest');
const app = require('../src/app/app');

describe('Notaire backend app', () => {
    test('GET /api/health returns 200', async () => {
        const response = await request(app).get('/api/health');

        expect(response.status).toBe(200);
        expect(response.body.success).toBe(true);
        expect(response.body.service).toBe('notaire-api');
    });

    test('GET /api/v1/health returns 200', async () => {
        const response = await request(app).get('/api/v1/health');

        expect(response.status).toBe(200);
        expect(response.body.success).toBe(true);
        expect(response.body.version).toBe('v1');
    });

    test('GET /api/auth/verify requires token', async () => {
        const response = await request(app).get('/api/auth/verify');

        expect(response.status).toBe(401);
        expect(response.body.success).toBe(false);
        expect(response.body.error.code).toBe('UNAUTHORIZED');
    });

    test('GET /api/v1/auth/verify requires token', async () => {
        const response = await request(app).get('/api/v1/auth/verify');

        expect(response.status).toBe(401);
        expect(response.body.success).toBe(false);
        expect(response.body.error.code).toBe('UNAUTHORIZED');
    });
});
