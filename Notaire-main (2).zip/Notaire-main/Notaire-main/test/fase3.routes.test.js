const request = require('supertest');
const { unauthorized } = require('../src/lib/errors');

const mockUsers = {
    client: { id: '11111111-1111-4111-8111-111111111111', role: 'cliente' },
    notary: { id: '22222222-2222-4222-8222-222222222222', role: 'notario' },
    otherNotary: { id: '33333333-3333-4333-8333-333333333333', role: 'notario' },
    admin: { id: '44444444-4444-4444-8444-444444444444', role: 'admin' }
};

jest.mock('../src/auth/auth.middleware', () => ({
    authMiddleware: (req, res, next) => {
        const { unauthorized: mockUnauthorized } = require('../src/lib/errors');
        const token = req.headers.authorization?.replace('Bearer ', '');
        if (!token || token === 'invalid') return next(mockUnauthorized('Token inválido o no autenticado.'));
        const user = mockUsers[token];
        if (!user) return next(mockUnauthorized('Token inválido o no autenticado.'));
        req.auth = { user, role: user.role, profile: { estado: 'active' } };
        return next();
    }
}));

jest.mock('../src/notarios/notario.service', () => ({
    getOwnProfile: jest.fn(async (id) => ({ usuario_id: id, estado: 'active' })),
    updateProfile: jest.fn(async (id, data) => ({ usuario_id: id, ...data })),
    listProfiles: jest.fn(async () => []),
    getProfile: jest.fn(async (id) => ({ usuario_id: id })),
    createProfile: jest.fn(async (data) => data),
    updateProfile: jest.fn(async (id, data) => ({ usuario_id: id, ...data }))
}));

jest.mock('../src/tramites/tramite.service', () => ({
    listTypes: jest.fn(async () => [{ id: 1, nombre: 'Compraventa', activo: true }]),
    getType: jest.fn(async (id) => ({ id, nombre: 'Compraventa', activo: true })),
    createType: jest.fn(async (data) => ({ id: 1, ...data })),
    updateType: jest.fn(async (id, data) => ({ id, ...data })),
    deactivateType: jest.fn(async () => undefined),
    createTramite: jest.fn(async (clienteId, data) => ({ id: 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa', cliente_id: clienteId, ...data })),
    listTramites: jest.fn(async (role, userId) => [{ id: 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa', scope: `${role}:${userId}` }]),
    getTramite: jest.fn(async (role, userId, id) => {
        const { notFound: mockNotFound } = require('../src/lib/errors');
        if (role === 'cliente' && id !== 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa') {
            throw mockNotFound('Trámite no encontrado o no accesible.');
        }
        if (role === 'notario' && id !== 'bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb') {
            throw mockNotFound('Trámite no encontrado o no accesible.');
        }
        return { id, scope: `${role}:${userId}` };
    }),
    updateTramite: jest.fn(async (role, userId, id, data) => ({ id, role, userId, ...data })),
    assignNotario: jest.fn(async (id, notarioId) => ({ id, notario_id: notarioId, estado: 'asignado' }))
}));

const app = require('../src/app/app');
const tramiteService = require('../src/tramites/tramite.service');

function auth(role) {
    return { Authorization: `Bearer ${role}` };
}

describe('Fase 3 API authorization and validation', () => {
    test('protected endpoint rejects missing and invalid tokens', async () => {
        expect((await request(app).get('/api/tramites')).status).toBe(401);
        expect((await request(app).get('/api/tramites').set(auth('invalid'))).status).toBe(401);
    });

    test('client and notary can consult active types', async () => {
        expect((await request(app).get('/api/tramites/tipos').set(auth('client'))).status).toBe(200);
        expect((await request(app).get('/api/tramites/tipos').set(auth('notary'))).status).toBe(200);
    });

    test('only admin can administer types', async () => {
        expect((await request(app).post('/api/tramites/tipos').set(auth('client')).send({ nombre: 'X' })).status).toBe(403);
        expect((await request(app).post('/api/tramites/tipos').set(auth('admin')).send({ nombre: 'X' })).status).toBe(201);
        expect((await request(app).put('/api/tramites/tipos/1').set(auth('admin')).send({ activo: false })).status).toBe(200);
        expect((await request(app).delete('/api/tramites/tipos/1').set(auth('admin'))).status).toBe(204);
    });

    test('client identity comes from auth and cannot be supplied', async () => {
        const response = await request(app).post('/api/tramites').set(auth('client')).send({
            cliente_id: mockUsers.admin.id,
            tipo_tramite_id: 1,
            titulo: 'Trámite propio'
        });
        expect(response.status).toBe(400);
        const valid = await request(app).post('/api/tramites').set(auth('client')).send({ tipo_tramite_id: 1, titulo: 'Trámite propio' });
        expect(valid.status).toBe(201);
        expect(tramiteService.createTramite).toHaveBeenCalledWith(mockUsers.client.id, expect.any(Object));
    });

    test('client can access own trámite but not another client trámite', async () => {
        expect((await request(app).get('/api/tramites/aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa').set(auth('client'))).status).toBe(200);
        expect((await request(app).get('/api/tramites/cccccccc-cccc-4ccc-8ccc-cccccccccccc').set(auth('client'))).status).toBe(404);
    });

    test('notary can access assigned trámite only and update allowed fields', async () => {
        expect((await request(app).get('/api/tramites/bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb').set(auth('notary'))).status).toBe(200);
        expect((await request(app).get('/api/tramites/aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa').set(auth('notary'))).status).toBe(404);
        expect((await request(app).patch('/api/tramites/bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb').set(auth('notary')).send({ estado: 'en_proceso' })).status).toBe(200);
    });

    test('admin can inspect all and assign a notary', async () => {
        expect((await request(app).get('/api/tramites').set(auth('admin'))).status).toBe(200);
        expect((await request(app).patch('/api/tramites/aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa/asignar-notario').set(auth('admin')).send({ notario_id: mockUsers.notary.id })).status).toBe(200);
    });

    test('admin notario profile identifiers require valid UUIDs', async () => {
        expect((await request(app).get('/api/notarios/not-an-id').set(auth('admin'))).status).toBe(400);
        expect((await request(app).get('/api/notarios/22222222-2222-4222-8222-222222222222').set(auth('admin'))).status).toBe(200);
        expect((await request(app).get('/api/notarios/%20').set(auth('admin'))).status).toBe(400);
    });

    test('invalid payload and invalid resource id are rejected', async () => {
        expect((await request(app).post('/api/tramites').set(auth('client')).send({ tipo_tramite_id: 1 })).status).toBe(400);
        expect((await request(app).get('/api/tramites/not-an-id').set(auth('client'))).status).toBe(400);
    });
});