const mockUser = {
    id: '22222222-2222-4222-8222-222222222222',
    email: 'notario@test.local'
};
let mockUserState = 'active';
let mockNotarioState = 'active';

jest.mock('../src/app/config/supabasePublic', () => ({
    getSupabasePublic: () => ({
        auth: {
            getUser: jest.fn(async () => ({ data: { user: mockUser }, error: null }))
        }
    })
}));

jest.mock('../src/app/config/supabaseAdmin', () => ({
    getSupabaseAdmin: () => ({
        from: (table) => ({
            select: () => ({
                eq: () => ({
                    maybeSingle: async () => {
                        if (table === 'usuarios') {
                            return {
                                data: {
                                    id: mockUser.id,
                                    nombre: 'Notario de prueba',
                                    telefono: '',
                                    estado: mockUserState,
                                    rol_id: 2,
                                    roles: { id: 2, nombre: 'notario' }
                                },
                                error: null
                            };
                        }
                        return {
                            data: { estado: mockNotarioState },
                            error: null
                        };
                    }
                })
            })
        })
    })
}));

const { authMiddleware } = require('../src/auth/auth.middleware');

async function runMiddleware() {
    const req = { headers: { authorization: 'Bearer test-token' } };
    const next = jest.fn();
    await authMiddleware(req, {}, next);
    return next;
}

describe('Notary and user status coherence', () => {
    beforeEach(() => {
        mockUserState = 'active';
        mockNotarioState = 'active';
    });

    test('active user with active notary profile is allowed', async () => {
        const next = await runMiddleware();

        expect(next).toHaveBeenCalledWith();
    });

    test('suspended user is rejected even with active notary profile', async () => {
        mockUserState = 'suspended';
        const next = await runMiddleware();

        expect(next.mock.calls[0][0].statusCode).toBe(403);
    });

    test('active user is rejected when notary profile is suspended', async () => {
        mockNotarioState = 'suspended';
        const next = await runMiddleware();

        expect(next.mock.calls[0][0].statusCode).toBe(403);
    });
});